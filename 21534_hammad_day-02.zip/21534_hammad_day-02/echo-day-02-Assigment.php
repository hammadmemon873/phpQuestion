<html>
<head>
<title>day 1st 'echo '</title>
</head>
<body>
<?php
echo "<h1 style =color:grey>DETAILS</h1>";
echo "<hr>";
echo "<strong>Name</strong> : <p>Hammad memon </P>";
echo "<strong>Contact Information</strong> : <p> 03332533044 </P>";
echo "<strong>Email </strong> : <p> hammadmemon873@gmail.com </P>";
echo "<hr>";
echo "<h1 style=color:grey>EDUCAION</h1>";
echo "<p> I Completed MY computer Science Degree From Sindh University Laar Campus Badin</p>";
echo "<hr>";
echo "<h1 style= color:grey>SKILLS</h1>";
echo "<p>little knowledge of HTML ,JAVASCRIPT ,C AND JAVA  </p>";
echo "<hr>";
echo "<h1 style = color:grey> EXPERIENCE </h1>";
echo "<p>i dont have experience  </p>";
echo "<hr>";
?>
</body>
</html>